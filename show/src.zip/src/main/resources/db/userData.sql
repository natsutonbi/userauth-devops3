insert into `User`.`user_login` 
(username,createtime,salt,password,nickname) VALUES 
('root',now(),'5422289147165366','9525a5c14d7a95c2caf1b9a22b739acc','admin');

insert into `User`.`message_recieve`
(username,email,tel) VALUES
('root','kv30246@163.com','');

insert into `User`.`message_recieve`
VALUES
('3619146277322752','','');

insert into `User`.`message_recieve`
VALUES
('3621404104720384','','');

